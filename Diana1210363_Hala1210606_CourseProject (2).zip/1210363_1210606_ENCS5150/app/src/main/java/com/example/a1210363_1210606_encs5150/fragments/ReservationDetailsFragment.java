package com.example.a1210363_1210606_encs5150.fragments;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReservationDetailsFragment extends Fragment {

    private ImageView imageProperty;
    private TextView textTitle, textLocation, textType, textPrice, textReservationDate;
    private Button btnConfirmReservation;
    private Button btnPickDate, btnPickTime;

    private Property property;
    private DatabaseHelper dbHelper;
    private String selectedDate;
    private String selectedTime;

    public static ReservationDetailsFragment newInstance(Property property) {
        ReservationDetailsFragment fragment = new ReservationDetailsFragment();
        Bundle args = new Bundle();
        args.putSerializable("property", property);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.reservation_details_fragment, container, false);

        imageProperty = view.findViewById(R.id.imageProperty);
        textTitle = view.findViewById(R.id.textTitle);
        textLocation = view.findViewById(R.id.textLocation);
        textType = view.findViewById(R.id.textType);
        textPrice = view.findViewById(R.id.textPrice);
        textReservationDate = view.findViewById(R.id.textReservationDate);
        btnConfirmReservation = view.findViewById(R.id.btnConfirmReservation);
        btnPickDate = view.findViewById(R.id.btnPickDate);
        btnPickTime = view.findViewById(R.id.btnPickTime);

        dbHelper = new DatabaseHelper(getContext());

        if (getArguments() != null) {
            property = (Property) getArguments().getSerializable("property");
            if (property != null) {
                textTitle.setText("Title: " + property.getTitle());
                textLocation.setText("Location: " + property.getLocation());
                textType.setText("Type: " + property.getType());
                textPrice.setText("Price: $" + property.getPrice());
                Glide.with(this).load(property.getImage()).into(imageProperty);
            }
        }

        selectedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        selectedTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        updateDateTimeLabel();

        btnPickDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePicker = new DatePickerDialog(getContext(),
                    (view1, year, month, dayOfMonth) -> {
                        selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                        updateDateTimeLabel();
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePicker.show();
        });

        btnPickTime.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog timePicker = new TimePickerDialog(getContext(),
                    (view2, hourOfDay, minute) -> {
                        selectedTime = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
                        updateDateTimeLabel();
                    },
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    true
            );
            timePicker.show();
        });

        btnConfirmReservation.setOnClickListener(v -> {
            if (property != null) {
                SharedPreferences prefs = requireContext().getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
                String userEmail = prefs.getString("email", "guest");

                boolean success = dbHelper.addReservation(userEmail, property.getId(), selectedDate, selectedTime);

                if (success) {
                    Toast.makeText(getContext(), "Reservation Confirmed", Toast.LENGTH_SHORT).show();
                    requireActivity().getSupportFragmentManager().popBackStack();
                } else {
                    Toast.makeText(getContext(), "You already reserved this property.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

    private void updateDateTimeLabel() {
        textReservationDate.setText("Reservation Date: " + selectedDate + "\nTime: " + selectedTime);
    }
}
