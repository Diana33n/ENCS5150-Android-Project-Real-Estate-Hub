package com.example.a1210363_1210606_encs5150.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.User;

public class RegisterActivity extends AppCompatActivity {

    EditText editEmail, editFirstName, editLastName, editPassword, editConfirmPassword, editPhone;
    Spinner spinnerGender, spinnerCountry, spinnerCity;
    Button btnRegister;
    ImageView togglePasswordEye, toggleConfirmPasswordEye;

    boolean isPasswordVisible = false;
    boolean isConfirmPasswordVisible = false;

    String[] genders = {"Male", "Female"};
    String[] countries = {"Palestine", "Jordan", "Egypt"};
    String[][] cities = {
            {"Ramallah", "Nablus", "Hebron"},
            {"Amman", "Zarqa", "Irbid"},
            {"Cairo", "Alexandria", "Giza"}
    };
    String[] countryCodes = {"+970", "+962", "+20"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize Views
        editEmail = findViewById(R.id.editEmail);
        editFirstName = findViewById(R.id.editFirstName);
        editLastName = findViewById(R.id.editLastName);
        editPassword = findViewById(R.id.editPassword);
        editConfirmPassword = findViewById(R.id.editConfirmPassword);
        editPhone = findViewById(R.id.editPhone);
        spinnerGender = findViewById(R.id.spinnerGender);
        spinnerCountry = findViewById(R.id.spinnerCountry);
        spinnerCity = findViewById(R.id.spinnerCity);
        btnRegister = findViewById(R.id.btnRegister);
        togglePasswordEye = findViewById(R.id.togglePasswordEye);
        toggleConfirmPasswordEye = findViewById(R.id.toggleConfirmPasswordEye);

        // Password toggle
        togglePasswordEye.setOnClickListener(v -> {
            if (isPasswordVisible) {
                editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                togglePasswordEye.setImageResource(R.drawable.ic_eye_closed);
            } else {
                editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                togglePasswordEye.setImageResource(R.drawable.ic_eye_open);
            }
            isPasswordVisible = !isPasswordVisible;
            editPassword.setSelection(editPassword.getText().length());
        });

        // Confirm Password toggle
        toggleConfirmPasswordEye.setOnClickListener(v -> {
            if (isConfirmPasswordVisible) {
                editConfirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                toggleConfirmPasswordEye.setImageResource(R.drawable.ic_eye_closed);
            } else {
                editConfirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                toggleConfirmPasswordEye.setImageResource(R.drawable.ic_eye_open);
            }
            isConfirmPasswordVisible = !isConfirmPasswordVisible;
            editConfirmPassword.setSelection(editConfirmPassword.getText().length());
        });

        // Spinners
        spinnerGender.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, genders));
        spinnerCountry.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, countries));

        spinnerCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < cities.length) {
                    spinnerCity.setAdapter(new ArrayAdapter<>(RegisterActivity.this, android.R.layout.simple_spinner_dropdown_item, cities[position]));
                    editPhone.setText(countryCodes[position]);
                } else {
                    editPhone.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        // Register Button
        btnRegister.setOnClickListener(v -> {
            if (!validateInputs()) return;

            DatabaseHelper db = new DatabaseHelper(this);
            String email = editEmail.getText().toString().trim();

            if (db.emailExists(email)) {
                Toast.makeText(this, "Email already registered", Toast.LENGTH_SHORT).show();
                return;
            }

            User newUser = new User(
                    editFirstName.getText().toString().trim(),
                    editLastName.getText().toString().trim(),
                    editEmail.getText().toString().trim(),
                    editPassword.getText().toString(),
                    spinnerGender.getSelectedItem().toString(),
                    spinnerCountry.getSelectedItem().toString(),
                    spinnerCity.getSelectedItem().toString(),
                    editPhone.getText().toString(),
                    "user"  // role
            );

            if (db.insertUser(newUser)) {
                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validateInputs() {
        String email = editEmail.getText().toString().trim();
        String fName = editFirstName.getText().toString().trim();
        String lName = editLastName.getText().toString().trim();
        String pass = editPassword.getText().toString();
        String conf = editConfirmPassword.getText().toString();

        if (!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")) {
            editEmail.setError("Invalid email");
            return false;
        }

        if (fName.length() < 3 || lName.length() < 3 || fName.matches(".*\\d.*") || lName.matches(".*\\d.*")) {
            Toast.makeText(this, "Name must be at least 3 characters and contain no numbers", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!pass.matches("^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{6,}$")) {
            editPassword.setError("Password must be 6+ chars, include letter, number & symbol");
            return false;
        }

        if (!pass.equals(conf)) {
            editConfirmPassword.setError("Passwords do not match");
            return false;
        }

        return true;
    }
}
