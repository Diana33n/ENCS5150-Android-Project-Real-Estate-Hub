package com.example.a1210363_1210606_encs5150.models;

public class ReservationDisplay {
    private Property property;
    private String date;
    private String time;

    public ReservationDisplay(Property property, String date, String time) {
        this.property = property;
        this.date = date;
        this.time = time;
    }

    public Property getProperty() {
        return property;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
}
