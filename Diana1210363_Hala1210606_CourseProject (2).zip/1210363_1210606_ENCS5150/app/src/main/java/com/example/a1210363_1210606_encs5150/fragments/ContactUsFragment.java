package com.example.a1210363_1210606_encs5150.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.example.a1210363_1210606_encs5150.R;

public class ContactUsFragment extends Fragment {

    private static final String PHONE_NUMBER = "+970599000000";
    private static final String EMAIL_ADDRESS = "RealEstateHub@agency.com";
    private static final String AGENCY_LOCATION = "geo:0,0?q=Your+Agency+Location+Here";

    public ContactUsFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact_us, container, false);

        Button btnCallUs = view.findViewById(R.id.btnCallUs);
        Button btnLocateUs = view.findViewById(R.id.btnLocateUs);
        Button btnEmailUs = view.findViewById(R.id.btnEmailUs);

        btnCallUs.setOnClickListener(v -> callAgency());
        btnLocateUs.setOnClickListener(v -> locateAgency());
        btnEmailUs.setOnClickListener(v -> emailAgency());

        return view;
    }

    private void callAgency() {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + PHONE_NUMBER));
        startActivity(intent);
    }

    private void locateAgency() {
        // You can replace this with your actual coordinates or address
        String map = "geo:31.9020,35.1956?q=Real+Estate+Agency";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(map));
        intent.setPackage("com.google.android.apps.maps");
        startActivity(intent);
    }

    private void emailAgency() {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:" + EMAIL_ADDRESS));
        startActivity(intent);
    }
}
