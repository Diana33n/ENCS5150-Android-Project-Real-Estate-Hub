package com.example.a1210363_1210606_encs5150.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.models.AdminReservation;

import java.util.List;

public class AdminReservationAdapter extends RecyclerView.Adapter<AdminReservationAdapter.VH> {

    private final List<AdminReservation> data;
    private final LayoutInflater inflater;

    public AdminReservationAdapter(Context context, List<AdminReservation> data) {
        this.inflater = LayoutInflater.from(context);
        this.data     = data;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_reservation, parent, false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        AdminReservation r = data.get(position);
        holder.textTitle.setText(r.title);
        holder.textLocation.setText(r.location);
        holder.textType.setText(r.type);
        holder.textPrice.setText(r.price);
        holder.textDateTime.setText(r.date + " " + r.time);

        if (r.imageUri != null && !r.imageUri.isEmpty()) {
            holder.imageProperty.setImageURI(Uri.parse(r.imageUri));
            holder.imageProperty.setVisibility(View.VISIBLE);
        } else {
            // استخدم أيقونة نظامية بدل placeholder مفقود
            holder.imageProperty.setImageResource(android.R.drawable.ic_menu_report_image);
            holder.imageProperty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView imageProperty;
        TextView textTitle, textLocation, textType, textPrice, textDateTime;

        VH(View itemView) {
            super(itemView);
            imageProperty = itemView.findViewById(R.id.imageProperty);
            textTitle     = itemView.findViewById(R.id.textTitle);
            textLocation  = itemView.findViewById(R.id.textLocation);
            textType      = itemView.findViewById(R.id.textType);
            textPrice     = itemView.findViewById(R.id.textPrice);
            textDateTime  = itemView.findViewById(R.id.textDateTime);
        }
    }
}
