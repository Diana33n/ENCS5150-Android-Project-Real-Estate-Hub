package com.example.a1210363_1210606_encs5150.fragments;
import com.example.a1210363_1210606_encs5150.models.ReservationDisplay;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.adapters.ReservationAdapter;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;
import java.util.List;

public class ReservationsFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView emptyText;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reservations, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewReservations);
        emptyText = view.findViewById(R.id.emptyReservationsText);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        loadReservations();

        return view;
    }

    private void loadReservations() {
        SharedPreferences prefs = requireContext().getSharedPreferences("user", Context.MODE_PRIVATE);
        String email = prefs.getString("email", "guest");

        DatabaseHelper db = new DatabaseHelper(getContext());
        List<ReservationDisplay> reservations = db.getReservationsWithDate(email);

        if (reservations.isEmpty()) {
            emptyText.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            emptyText.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            recyclerView.setAdapter(new ReservationAdapter(getContext(), reservations));
        }
    }

}
