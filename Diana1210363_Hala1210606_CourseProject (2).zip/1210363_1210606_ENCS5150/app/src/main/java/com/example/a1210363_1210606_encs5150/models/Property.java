package com.example.a1210363_1210606_encs5150.models;
import java.io.Serializable;

public class Property implements Serializable {
    private int id;
    private String title;
    private String description;
    private double price;
    private String location;
    private String image;
    private String type;

    // Empty constructor for DatabaseHelper
    public Property() {
    }

    // Constructor for easier object creation
    public Property(int id, String title, String description, double price, String location, String image, String type) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.location = location;
        this.image = image;
        this.type = type;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}