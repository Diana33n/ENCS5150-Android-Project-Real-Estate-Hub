package com.example.a1210363_1210606_encs5150.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.adapters.FavoriteAdapter;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;

import java.util.List;

public class FavoritesFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView textEmpty;
    private DatabaseHelper dbHelper;

    public FavoritesFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorites, container, false);

        recyclerView = view.findViewById(R.id.recyclerFavorites);
        textEmpty = view.findViewById(R.id.textEmptyFavorites);

        dbHelper = new DatabaseHelper(getContext());

        SharedPreferences prefs = requireContext().getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
        String email = prefs.getString("email", "guest");

        List<Property> favorites = dbHelper.getFavorites(email);

        if (favorites.isEmpty()) {
            textEmpty.setVisibility(View.VISIBLE);
        } else {
            textEmpty.setVisibility(View.GONE);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            FavoriteAdapter adapter = new FavoriteAdapter((FragmentActivity) getActivity(), favorites, email, dbHelper);
            recyclerView.setAdapter(adapter);
        }

        return view;
    }
}
