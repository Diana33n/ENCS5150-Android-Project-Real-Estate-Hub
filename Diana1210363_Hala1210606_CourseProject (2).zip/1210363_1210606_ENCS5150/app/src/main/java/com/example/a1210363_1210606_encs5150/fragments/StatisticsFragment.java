package com.example.a1210363_1210606_encs5150.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;

import java.util.Map;

public class StatisticsFragment extends Fragment {

    private DatabaseHelper db;
    private TextView txtTotalUsers, txtTotalReservations, txtGenderStats, txtCountryStats;

    public StatisticsFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_statistics, container, false);

        db = new DatabaseHelper(requireContext());

        txtTotalUsers = view.findViewById(R.id.txtTotalUsers);
        txtTotalReservations = view.findViewById(R.id.txtTotalReservations);
        txtGenderStats = view.findViewById(R.id.txtGenderStats);
        txtCountryStats = view.findViewById(R.id.txtCountryStats);

        loadStatistics();

        return view;
    }

    private void loadStatistics() {
        int totalUsers = db.getTotalUsers();
        int totalReservations = db.getTotalReservations();
        Map<String, Integer> genderStats = db.getGenderStats();
        Map<String, Integer> countryStats = db.getCountryStats();

        txtTotalUsers.setText("Total Users: " + totalUsers);
        txtTotalReservations.setText("Total Reservations: " + totalReservations);

        StringBuilder genderText = new StringBuilder("Gender Stats:\n");
        for (String gender : genderStats.keySet()) {
            genderText.append("• ").append(gender).append(": ").append(genderStats.get(gender)).append("\n");
        }
        txtGenderStats.setText(genderText.toString().trim());

        StringBuilder countryText = new StringBuilder("Country Stats:\n");
        for (String country : countryStats.keySet()) {
            countryText.append("• ").append(country).append(": ").append(countryStats.get(country)).append("\n");
        }
        txtCountryStats.setText(countryText.toString().trim());
    }

}
