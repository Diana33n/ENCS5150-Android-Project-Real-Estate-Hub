package com.example.a1210363_1210606_encs5150.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.a1210363_1210606_encs5150.R;

import org.json.JSONObject;
import com.example.a1210363_1210606_encs5150.models.Property;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;

import org.json.JSONArray;

public class WelcomeActivity extends AppCompatActivity {

    private Button btnConnect;
    private static final String TAG = "WelcomeActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        btnConnect = findViewById(R.id.btnConnect);

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkApiConnection();
            }
        });
    }

    private void checkApiConnection() {
        String apiUrl = "https://api.jsonbin.io/v3/b/6846db708561e97a50216a00";

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET,
                apiUrl,
                null,
                response -> {
                    try {
                        DatabaseHelper db = new DatabaseHelper(WelcomeActivity.this);

                        JSONObject record = response.getJSONObject("record");

                        if (record.has("properties")) {
                            JSONArray propertiesArray = record.getJSONArray("properties");

                            for (int i = 0; i < propertiesArray.length(); i++) {
                                JSONObject obj = propertiesArray.getJSONObject(i);

                                Property property = new Property();
                                property.setId(obj.getInt("id"));
                                property.setTitle(obj.getString("title"));
                                property.setDescription(obj.getString("description"));
                                property.setPrice(obj.getDouble("price"));
                                property.setLocation(obj.getString("location"));
                                property.setImage(obj.getString("image_url"));
                                property.setType(obj.getString("type"));

                                db.insertOrUpdateProperty(property); // ✅ تأكد أنها موجودة فعلاً بملف DatabaseHelper
                            }
                        }


                        Toast.makeText(this, "Connected and data loaded!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, LoginActivity.class));

                    } catch (Exception e) {
                        Log.e(TAG, "JSON Parsing error", e);
                        Toast.makeText(this, "Failed to parse data", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    Toast.makeText(this, "Connection Failed: " + error.toString(), Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Volley Error: ", error);
                }
        );

        queue.add(request);
    }

}
