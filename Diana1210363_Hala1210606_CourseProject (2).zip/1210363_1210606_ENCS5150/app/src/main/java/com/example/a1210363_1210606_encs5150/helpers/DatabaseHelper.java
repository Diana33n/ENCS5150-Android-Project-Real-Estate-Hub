package com.example.a1210363_1210606_encs5150.helpers;
import java.util.Map; // Added by Hala
import java.util.HashMap; // Added by Hala
import org.json.JSONArray;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.a1210363_1210606_encs5150.models.Property;
import com.example.a1210363_1210606_encs5150.models.User;

import java.util.ArrayList;
import java.util.List;
import com.example.a1210363_1210606_encs5150.models.ReservationDisplay;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "RealEstateDB";
    private static final int DB_VERSION = 2;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //hala add
        // USERS
        String createUsersTable = "CREATE TABLE users (" +  //hala add
                "email TEXT PRIMARY KEY," +  //hala add
                "firstName TEXT," +  //hala add
                "lastName TEXT," +  //hala add
                "password TEXT," +  //hala add
                "gender TEXT," +  //hala add
                "country TEXT," +  //hala add
                "city TEXT," +  //hala add
                "phone TEXT," +  //hala add
                "profileImage BLOB," +//// hala add this at 4 pm
                "role TEXT DEFAULT 'user')";  //hala add
        db.execSQL(createUsersTable);  //hala add
        //hala add
        db.execSQL("INSERT INTO users (email, firstName, lastName, password, gender, country, city, phone, role) " +
                "VALUES ('admin@admin.com', 'Admin', 'Admin', 'Admin123!', 'Male', 'Palestine', 'Ramallah', '+970599000000', 'admin')");
//hala end  add

        // PROPERTIES (بدون AUTOINCREMENT)
        String createPropertiesTable = "CREATE TABLE Properties (" +
                "id INTEGER PRIMARY KEY," +
                "title TEXT," +
                "description TEXT," +
                "price REAL," +
                "location TEXT," +
                "image TEXT," +
                "type TEXT," +
                "isFeatured INTEGER DEFAULT 0)";  // Added by Hala

        db.execSQL(createPropertiesTable);

        // RESERVATIONS
        String createReservationsTable = "CREATE TABLE reservations (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_email TEXT," +
                "property_id INTEGER," +
                "reservation_date TEXT," +
                "reservation_time TEXT)";
        db.execSQL(createReservationsTable);


        String createFavoritesTable = "CREATE TABLE favorites (" +
                "user_email TEXT," +
                "property_id INTEGER," +
                "PRIMARY KEY(user_email, property_id))";

        db.execSQL(createFavoritesTable);

    }
    // ***************************This method add by hala*********
    public String getUserRole(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"role"}, "email=?", new String[]{email}, null, null, null);
        if (cursor.moveToFirst()) {
            String role = cursor.getString(cursor.getColumnIndexOrThrow("role"));
            cursor.close();
            db.close();
            return role;
        }
        cursor.close();
        db.close();
        return null;  // email not found (should not happen after login)
    }
    // Added by Hala
    public List<String> getAllCustomers() {
        List<String> customers = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"email"}, "role=?", new String[]{"user"}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                customers.add(cursor.getString(cursor.getColumnIndexOrThrow("email")));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return customers;
    }

    // Added by Hala
    public void deleteUser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("users", "email=?", new String[]{email});
        db.close();
    }

    // Added by Hala
    public int getTotalUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM users WHERE role = 'user'", null);
        int count = 0;
        if (cursor.moveToFirst()) count = cursor.getInt(0);
        cursor.close();
        db.close();
        return count;
    }

    // Added by Hala
    public int getTotalReservations() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM reservations", null);
        int count = 0;
        if (cursor.moveToFirst()) count = cursor.getInt(0);
        cursor.close();
        db.close();
        return count;
    }

    // Added by Hala
    public Map<String, Integer> getGenderStats() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT gender, COUNT(*) FROM users WHERE role='user' GROUP BY gender", null);
        Map<String, Integer> map = new HashMap<>();

        if (cursor.moveToFirst()) {
            do {
                map.put(cursor.getString(0), cursor.getInt(1));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return map;
    }


    // Added by Hala
    public Map<String, Integer> getCountryStats() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT country, COUNT(*) FROM users WHERE role='user' GROUP BY country", null);
        Map<String, Integer> map = new HashMap<>();

        if (cursor.moveToFirst()) {
            do {
                map.put(cursor.getString(0), cursor.getInt(1));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return map;
    }

    public boolean addFavorite(String email, int propertyId) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM favorites WHERE user_email = ? AND property_id = ?",
                new String[]{email, String.valueOf(propertyId)}
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();

        if (exists) {
            db.close();
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("user_email", email);
        values.put("property_id", propertyId);

        long result = db.insert("favorites", null, values);
        db.close();
        return result != -1;
    }
    public void removeFavorite(String email, int propertyId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("favorites", "user_email=? AND property_id=?", new String[]{email, String.valueOf(propertyId)});
        db.close();
    }

    // Added by Hala
// Added by Hala
    public long insertAdmin(User admin) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("firstName", admin.getFirstName());
        values.put("lastName", admin.getLastName());
        values.put("email", admin.getEmail());
        values.put("password", admin.getPassword());
        values.put("gender", admin.getGender());
        values.put("country", admin.getCountry());
        values.put("city", admin.getCity());
        values.put("phone", admin.getPhone());
        values.put("role", admin.getRole());

        // Check if email already exists
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE email = ?", new String[]{admin.getEmail()});
        if (cursor.moveToFirst()) {
            cursor.close();
            return -1; // Email already exists
        }
        cursor.close();

        return db.insert("users", null, values); // return the row ID (or -1 on failure)
    }

    // Added by Hala
    public List<String> getAllReservationsForAdmin() {
        List<String> reservations = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT r.user_email, p.title, r.reservation_date, r.reservation_time " +
                "FROM reservations r JOIN Properties p ON r.property_id = p.id";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String email = cursor.getString(0);
                String title = cursor.getString(1);
                String date = cursor.getString(2);
                String time = cursor.getString(3);

                String resInfo = "Customer: " + email + "\nProperty: " + title +
                        "\nDate: " + date + " " + time;
                reservations.add(resInfo);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return reservations;
    }

    // Added by Hala
    public List<String> getAllPropertyTitles() {
        List<String> titles = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT title FROM Properties", null);
        while (cursor.moveToNext()) {
            titles.add(cursor.getString(0));
        }
        cursor.close();
        db.close();
        return titles;
    }

    // Added by Hala
    public void toggleFeatured(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT isFeatured FROM Properties WHERE id = ?", new String[]{String.valueOf(id)});
        if (cursor.moveToFirst()) {
            int current = cursor.getInt(0);
            int newValue = (current == 0) ? 1 : 0;
            ContentValues values = new ContentValues();
            values.put("isFeatured", newValue);
            db.update("Properties", values, "id = ?", new String[]{String.valueOf(id)});
        }
        cursor.close();
        db.close();
    }

    // Added by Hala
    public List<Property> getFeaturedProperties() {
        List<Property> featured = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Properties WHERE isFeatured = 1", null);

        if (cursor.moveToFirst()) {
            do {
                Property property = new Property();
                property.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                property.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
                property.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("description")));
                property.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("price")));
                property.setLocation(cursor.getString(cursor.getColumnIndexOrThrow("location")));
                property.setImage(cursor.getString(cursor.getColumnIndexOrThrow("image")));
                property.setType(cursor.getString(cursor.getColumnIndexOrThrow("type")));
                featured.add(property);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return featured;
    }

    public List<ReservationDisplay> getReservationsWithDate(String email) {
        List<ReservationDisplay> result = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT p.*, r.reservation_date, r.reservation_time " +
                "FROM reservations r " +
                "JOIN Properties p ON r.property_id = p.id " +
                "WHERE r.user_email = ?";

        Cursor cursor = db.rawQuery(query, new String[]{email});

        if (cursor.moveToFirst()) {
            do {
                Property property = new Property();
                property.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                property.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
                property.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("description")));
                property.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("price")));
                property.setLocation(cursor.getString(cursor.getColumnIndexOrThrow("location")));
                property.setImage(cursor.getString(cursor.getColumnIndexOrThrow("image")));
                property.setType(cursor.getString(cursor.getColumnIndexOrThrow("type")));

                String date = cursor.getString(cursor.getColumnIndexOrThrow("reservation_date"));
                String time = cursor.getString(cursor.getColumnIndexOrThrow("reservation_time"));

                result.add(new ReservationDisplay(property, date, time));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return result;
    }

    //**finish add by hala *****************************
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS Properties");
        db.execSQL("DROP TABLE IF EXISTS reservations");
        db.execSQL("DROP TABLE IF EXISTS favorites");

        onCreate(db);
    }

    public boolean insertUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", user.getEmail());
        values.put("firstName", user.getFirstName());
        values.put("lastName", user.getLastName());
        values.put("password", user.getPassword());
        values.put("gender", user.getGender());
        values.put("country", user.getCountry());
        values.put("city", user.getCity());
        values.put("phone", user.getPhone());
        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"email"}, "email=? AND password=?",
                new String[]{email, password}, null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();
        return exists;
    }

    public boolean emailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users", new String[]{"email"}, "email=?",
                new String[]{email}, null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();
        return exists;
    }

    public boolean addReservation(String email, int propertyId, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();

        // ✅ تحقق من التكرار
        Cursor cursor = db.rawQuery(
                "SELECT * FROM reservations WHERE user_email = ? AND property_id = ?",
                new String[]{email, String.valueOf(propertyId)}
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();

        if (exists) {
            db.close();
            return false; // ⚠ حجز مكرر
        }

        // ✅ إذا مش مكرر → أضف الحجز
        ContentValues values = new ContentValues();
        values.put("user_email", email);
        values.put("property_id", propertyId);
        values.put("reservation_date", date);
        values.put("reservation_time", time);
        long result = db.insert("reservations", null, values);
        db.close();
        return result != -1;
    }
    // إضافة للمفضلة
    public boolean addToFavorites(String email, int propertyId) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM favorites WHERE user_email = ? AND property_id = ?",
                new String[]{email, String.valueOf(propertyId)});
        boolean exists = cursor.moveToFirst();
        cursor.close();

        if (exists) {
            db.close();
            return false; // موجود مسبقًا
        }

        ContentValues values = new ContentValues();
        values.put("user_email", email);
        values.put("property_id", propertyId);
        long result = db.insert("favorites", null, values);
        db.close();
        return result != -1;
    }

    // إزالة من المفضلة
    public boolean removeFromFavorites(String email, int propertyId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("favorites", "user_email=? AND property_id=?", new String[]{email, String.valueOf(propertyId)});
        db.close();
        return result > 0;
    }


    // جلب قائمة المفضلة
    public List<Property> getFavorites(String email) {
        List<Property> favorites = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT p.* FROM favorites f JOIN Properties p ON f.property_id = p.id WHERE f.user_email = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email});

        if (cursor.moveToFirst()) {
            do {
                Property property = new Property();
                property.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                property.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
                property.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("description")));
                property.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("price")));
                property.setLocation(cursor.getString(cursor.getColumnIndexOrThrow("location")));
                property.setImage(cursor.getString(cursor.getColumnIndexOrThrow("image")));
                property.setType(cursor.getString(cursor.getColumnIndexOrThrow("type")));
                favorites.add(property);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return favorites;
    }

    public List<Property> getReservationsByUser(String email) {
        List<Property> reservations = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT p.* FROM reservations r JOIN Properties p ON r.property_id = p.id WHERE r.user_email = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email});

        if (cursor.moveToFirst()) {
            do {
                Property property = new Property();
                property.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                property.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
                property.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("description")));
                property.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("price")));
                property.setLocation(cursor.getString(cursor.getColumnIndexOrThrow("location")));
                property.setImage(cursor.getString(cursor.getColumnIndexOrThrow("image")));
                property.setType(cursor.getString(cursor.getColumnIndexOrThrow("type")));
                reservations.add(property);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return reservations;
    }

    public List<Property> getAllProperties() {
        List<Property> properties = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Properties", null);

        if (cursor.moveToFirst()) {
            do {
                Property property = new Property();
                property.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                property.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
                property.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("description")));
                property.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("price")));
                property.setLocation(cursor.getString(cursor.getColumnIndexOrThrow("location")));
                property.setImage(cursor.getString(cursor.getColumnIndexOrThrow("image")));
                property.setType(cursor.getString(cursor.getColumnIndexOrThrow("type")));
                properties.add(property);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return properties;
    }
    public void insertOrUpdateProperty(Property property) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT isFeatured FROM Properties WHERE id = ?", new String[]{String.valueOf(property.getId())});
        boolean exists = cursor.moveToFirst();

        int isFeatured = 0; // default
        if (exists) {
            isFeatured = cursor.getInt(0); // احتفظ بالقيمة القديمة
        }

        cursor.close();

        ContentValues values = new ContentValues();
        values.put("id", property.getId());
        values.put("title", property.getTitle());
        values.put("description", property.getDescription());
        values.put("price", property.getPrice());
        values.put("location", property.getLocation());
        values.put("image", property.getImage());
        values.put("type", property.getType());
        values.put("isFeatured", isFeatured);  // ✅ حافظ على القيمة القديمة

        if (exists) {
            db.update("Properties", values, "id = ?", new String[]{String.valueOf(property.getId())});
        } else {
            db.insert("Properties", null, values);
        }

        db.close();
    }
    public boolean insertProperty(Property property) {
        if (propertyExists(property.getId())) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id", property.getId());
        values.put("title", property.getTitle());
        values.put("description", property.getDescription());
        values.put("price", property.getPrice());
        values.put("location", property.getLocation());
        values.put("image", property.getImage());
        values.put("type", property.getType());
        values.put("isFeatured", 0);

        long result = db.insert("Properties", null, values);
        db.close();
        return result != -1;
    }

    public boolean propertyExists(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM Properties WHERE id = ?", new String[]{String.valueOf(id)});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();
        return exists;
    }


}