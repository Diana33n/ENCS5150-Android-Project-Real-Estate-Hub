package com.example.a1210363_1210606_encs5150.fragments;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.adapters.PropertyAdapter;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;

import java.util.List;

public class FeaturedFragment extends Fragment {

    private RecyclerView recyclerView;
    private DatabaseHelper dbHelper;

    public FeaturedFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_featured, container, false);

        recyclerView = view.findViewById(R.id.recyclerFeatured);
        dbHelper = new DatabaseHelper(requireContext());

        List<Property> featured = dbHelper.getFeaturedProperties();
        Log.d("FeaturedFragment", "Found " + featured.size() + " featured properties");

        if (featured.isEmpty()) {
            Toast.makeText(getContext(), "No featured properties found", Toast.LENGTH_LONG).show();
        }

        PropertyAdapter adapter = new PropertyAdapter((FragmentActivity) getActivity(), featured);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        return view;
    }
}
