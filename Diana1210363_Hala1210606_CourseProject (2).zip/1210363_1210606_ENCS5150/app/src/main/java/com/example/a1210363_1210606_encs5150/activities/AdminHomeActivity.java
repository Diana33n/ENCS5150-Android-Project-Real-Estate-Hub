package com.example.a1210363_1210606_encs5150.activities;
import com.example.a1210363_1210606_encs5150.fragments.DeleteCustomersFragment;  // Added by Hala
import com.example.a1210363_1210606_encs5150.fragments.StatisticsFragment;       // Added by Hala
import com.example.a1210363_1210606_encs5150.fragments.AddAdminFragment;
import com.example.a1210363_1210606_encs5150.fragments.ViewReservationsFragment;
import com.example.a1210363_1210606_encs5150.fragments.AdminSpecialOffersFragment;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.a1210363_1210606_encs5150.R;
import com.google.android.material.navigation.NavigationView;

public class AdminHomeActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);  // Added by Hala

        drawerLayout = findViewById(R.id.drawerLayoutAdmin);
        navigationView = findViewById(R.id.navigationViewAdmin);
        toolbar = findViewById(R.id.toolbarAdmin);
        setSupportActionBar(toolbar);

        toggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.nav_delete_customers) {
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.adminContentFrame, new DeleteCustomersFragment())
                            .commit();
                }
                else if (id == R.id.nav_statistics) {
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.adminContentFrame, new StatisticsFragment())
                            .commit();
                }
                else if (id == R.id.nav_add_admin) {
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.adminContentFrame, new AddAdminFragment())
                            .commit();
                }
                else if (id == R.id.nav_view_reservations) {
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.adminContentFrame, new ViewReservationsFragment())
                            .commit();
                }
                else if (id == R.id.nav_special_offers) {
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.adminContentFrame, new AdminSpecialOffersFragment())
                            .commit();
                }
                else if (id == R.id.nav_logout) {
                    startActivity(new Intent(AdminHomeActivity.this, LoginActivity.class));
                    finish();
                }

                drawerLayout.closeDrawers();
                return true;
            }
        });
    }
}
