package com.example.a1210363_1210606_encs5150.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.models.Property;
import com.example.a1210363_1210606_encs5150.models.ReservationDisplay;

import java.util.List;

public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ViewHolder> {

    private Context context;
    private List<ReservationDisplay> reservations;

    public ReservationAdapter(Context context, List<ReservationDisplay> reservations) {
        this.context = context;
        this.reservations = reservations;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_reservation, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ReservationDisplay res = reservations.get(position);
        Property property = res.getProperty();

        holder.textTitle.setText(property.getTitle());
        holder.textLocation.setText(property.getLocation());
        holder.textType.setText(property.getType());
        holder.textPrice.setText("$" + property.getPrice());
        holder.textDateTime.setText("Date: " + res.getDate() + " | Time: " + res.getTime());

        Glide.with(context)
                .load(property.getImage())
                .into(holder.imageProperty);
    }

    @Override
    public int getItemCount() {
        return reservations.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageProperty;
        TextView textTitle, textLocation, textType, textPrice, textDateTime;

        public ViewHolder(View itemView) {
            super(itemView);
            imageProperty = itemView.findViewById(R.id.imageProperty);
            textTitle = itemView.findViewById(R.id.textTitle);
            textLocation = itemView.findViewById(R.id.textLocation);
            textType = itemView.findViewById(R.id.textType);
            textPrice = itemView.findViewById(R.id.textPrice);
            textDateTime = itemView.findViewById(R.id.textDateTime);
        }
    }
}
