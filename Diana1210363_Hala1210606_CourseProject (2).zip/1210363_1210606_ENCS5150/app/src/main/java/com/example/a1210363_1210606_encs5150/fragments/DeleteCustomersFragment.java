package com.example.a1210363_1210606_encs5150.fragments;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class DeleteCustomersFragment extends Fragment {

    private ListView listView;
    private DatabaseHelper db;
    private List<String> customerEmails;
    private ArrayAdapter<String> adapter;

    public DeleteCustomersFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_delete_customers, container, false);

        listView = view.findViewById(R.id.listViewCustomers);
        db = new DatabaseHelper(getContext());

        loadCustomers();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedEmail = customerEmails.get(position);
                confirmDelete(selectedEmail);
            }
        });

        return view;
    }

    private void loadCustomers() {
        customerEmails = db.getAllCustomers();
        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, customerEmails);
        listView.setAdapter(adapter);
    }

    private void confirmDelete(String email) {
        new AlertDialog.Builder(getContext())
                .setTitle("Delete Customer")
                .setMessage("Are you sure you want to delete: " + email + "?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    db.deleteUser(email);
                    Toast.makeText(getContext(), "Customer deleted", Toast.LENGTH_SHORT).show();
                    loadCustomers();
                })
                .setNegativeButton("No", null)
                .show();
    }
}
