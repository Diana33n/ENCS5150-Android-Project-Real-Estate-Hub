package com.example.a1210363_1210606_encs5150.activities;
import com.example.a1210363_1210606_encs5150.fragments.AboutUsFragment;
import com.example.a1210363_1210606_encs5150.fragments.ProfileFragment;
import com.example.a1210363_1210606_encs5150.fragments.FeaturedFragment;//add by hala
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;
import com.example.a1210363_1210606_encs5150.fragments.ContactUsFragment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.fragments.PropertiesFragment;
import com.google.android.material.navigation.NavigationView;
import com.example.a1210363_1210606_encs5150.fragments.YourReservationsFragment;
import com.example.a1210363_1210606_encs5150.fragments.FavoritesFragment;



public class HomeActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setContentView(R.layout.activity_home);

            drawerLayout = findViewById(R.id.drawerLayout);
            navigationView = findViewById(R.id.navigationView);
            toolbar = findViewById(R.id.toolbar);

            setSupportActionBar(toolbar);

            toggle = new ActionBarDrawerToggle(
                    this,
                    drawerLayout,
                    toolbar,
                    R.string.navigation_drawer_open,
                    R.string.navigation_drawer_close
            );
            drawerLayout.addDrawerListener(toggle);
            toggle.syncState();

            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    int id = item.getItemId();

                    if (id == R.id.nav_home) {
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.content_frame, new AboutUsFragment())
                                .commit();
                    } else if (id == R.id.nav_properties) {
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.content_frame, new PropertiesFragment())
                                .commit();
                    } else if (id == R.id.nav_reservations) {
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.content_frame, new YourReservationsFragment())
                                .commit();
                    }
                    else if (id == R.id.nav_favorites) {
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.content_frame, new FavoritesFragment())  // ✅ تأكد أنه موجود
                                .commit();
                    }
                    else if (id == R.id.nav_featured) {
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.content_frame, new FeaturedFragment())
                                .commit();
                    }
                    else if (id == R.id.nav_profile) {
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.content_frame, new ProfileFragment())
                                .commit();
                    }
                    else if (id == R.id.nav_contact) {
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.content_frame, new ContactUsFragment())
                                .commit();
                    }
                    else if (id == R.id.nav_logout) {
                        Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }

                    drawerLayout.closeDrawers();
                    return true;
                }
            });

        } catch (Exception e) {
            Toast.makeText(this, "Crash: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}