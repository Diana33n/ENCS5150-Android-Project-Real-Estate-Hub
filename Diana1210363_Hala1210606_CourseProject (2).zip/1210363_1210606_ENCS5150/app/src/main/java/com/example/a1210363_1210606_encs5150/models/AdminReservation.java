package com.example.a1210363_1210606_encs5150.models;

public class AdminReservation {
    public final String firstName, lastName, email;
    public final String title, location, type, price, imageUri, date, time;

    public AdminReservation(String firstName, String lastName, String email,
                            String title, String location, String type,
                            String price, String imageUri,
                            String date, String time) {
        this.firstName = firstName;
        this.lastName  = lastName;
        this.email     = email;
        this.title     = title;
        this.location  = location;
        this.type      = type;
        this.price     = price;
        this.imageUri  = imageUri;
        this.date      = date;
        this.time      = time;
    }
}