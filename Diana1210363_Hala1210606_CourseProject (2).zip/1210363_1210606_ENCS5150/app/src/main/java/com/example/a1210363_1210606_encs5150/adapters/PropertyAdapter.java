package com.example.a1210363_1210606_encs5150.adapters;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.fragments.ReservationDetailsFragment;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;

import java.util.ArrayList;
import java.util.List;

public class PropertyAdapter extends RecyclerView.Adapter<PropertyAdapter.PropertyViewHolder> {

    private FragmentActivity activity;
    private List<Property> propertyList;
    private List<Property> fullList;

    public PropertyAdapter(FragmentActivity activity, List<Property> propertyList) {
        this.activity = activity;
        this.propertyList = new ArrayList<>(propertyList);
        this.fullList = new ArrayList<>(propertyList);
    }

    @Override
    public PropertyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.item_property, parent, false);
        return new PropertyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PropertyViewHolder holder, int position) {
        Property property = propertyList.get(position);
        holder.textTitle.setText(property.getTitle());
        holder.textLocation.setText(property.getLocation());
        holder.textPrice.setText("$" + property.getPrice());
        holder.textDetails.setText(property.getType());
        Glide.with(holder.itemView.getContext()).load(property.getImage()).into(holder.imageProperty);

        DatabaseHelper dbHelper = new DatabaseHelper(activity);

        // Reserve Button
        holder.btnReserve.setOnClickListener(v -> {
            int propertyId = insertOrGetPropertyId(dbHelper, property);

            if (propertyId != -1) {
                property.setId(propertyId);
                Bundle bundle = new Bundle();
                bundle.putSerializable("property", property);

                ReservationDetailsFragment fragment = new ReservationDetailsFragment();
                fragment.setArguments(bundle);

                activity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.content_frame, fragment)
                        .addToBackStack(null)
                        .commit();
            } else {
                Toast.makeText(activity, "Error saving property", Toast.LENGTH_SHORT).show();
            }
        });

        // Add to Favorites Button
        holder.btnAddFavorite.setOnClickListener(v -> {
            SharedPreferences prefs = activity.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
            String email = prefs.getString("email", "guest");

            // 🟢 تأكد من وجود العقار أولاً في الجدول
            int propertyId = insertOrGetPropertyId(dbHelper, property);
            property.setId(propertyId);

            boolean added = dbHelper.addToFavorites(email, propertyId);

            if (added) {
                Toast.makeText(activity, "Added to favorites", Toast.LENGTH_SHORT).show();
            } else {
                boolean removed = dbHelper.removeFromFavorites(email, propertyId);
                if (removed) {
                    Toast.makeText(activity, "Removed from favorites", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity, "Something went wrong", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return propertyList.size();
    }

    private int insertOrGetPropertyId(DatabaseHelper db, Property property) {
        SQLiteDatabase database = db.getWritableDatabase();
        Cursor cursor = null;
        int id = -1;

        try {
            cursor = database.rawQuery("SELECT id FROM Properties WHERE id = ?", new String[]{String.valueOf(property.getId())});
            if (cursor.moveToFirst()) {
                id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            } else {
                ContentValues values = new ContentValues();
                values.put("id", property.getId());
                values.put("title", property.getTitle());
                values.put("description", property.getDescription());
                values.put("price", property.getPrice());
                values.put("location", property.getLocation());
                values.put("image", property.getImage());
                values.put("type", property.getType());

                long newId = database.insert("Properties", null, values);
                if (newId != -1) {
                    id = property.getId();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            database.close();
        }

        return id;
    }

    public static class PropertyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageProperty;
        TextView textTitle, textLocation, textPrice, textDetails;
        Button btnReserve, btnAddFavorite;

        public PropertyViewHolder(View itemView) {
            super(itemView);
            imageProperty = itemView.findViewById(R.id.imageProperty);
            textTitle = itemView.findViewById(R.id.textTitle);
            textLocation = itemView.findViewById(R.id.textLocation);
            textPrice = itemView.findViewById(R.id.textPrice);
            textDetails = itemView.findViewById(R.id.textDetails);
            btnReserve = itemView.findViewById(R.id.btnReserve);
            btnAddFavorite = itemView.findViewById(R.id.btnAddFavorite);
        }
    }

    public void filter(String query) {
        propertyList.clear();
        if (query.isEmpty()) {
            propertyList.addAll(fullList);
        } else {
            query = query.toLowerCase();
            for (Property property : fullList) {
                if (property.getTitle().toLowerCase().contains(query)
                        || property.getLocation().toLowerCase().contains(query)
                        || property.getType().toLowerCase().contains(query)
                        || String.valueOf(property.getPrice()).contains(query)) {
                    propertyList.add(property);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void filterByType(String type) {
        propertyList.clear();
        if (type.equals("All")) {
            propertyList.addAll(fullList);
        } else {
            for (Property property : fullList) {
                if (property.getType().equalsIgnoreCase(type)) {
                    propertyList.add(property);
                }
            }
        }
        notifyDataSetChanged();
    }
}
