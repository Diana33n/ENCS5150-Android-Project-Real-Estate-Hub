package com.example.a1210363_1210606_encs5150.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;

import java.util.List;

public class AdminSpecialOffersFragment extends Fragment {

    private DatabaseHelper db;
    private LinearLayout container;

    public AdminSpecialOffersFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup containerView, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_special_offers, containerView, false);

        container = view.findViewById(R.id.propertiesContainer);
        db = new DatabaseHelper(requireContext());

        Toast.makeText(getContext(), "Special Offers Fragment Loaded", Toast.LENGTH_SHORT).show();

        loadProperties();
        return view;
    }

    private void loadProperties() {
        container.removeAllViews();

        List<Property> allProperties = db.getAllProperties();
        List<Property> featuredList = db.getFeaturedProperties();

        if (allProperties.isEmpty()) {
            Toast.makeText(getContext(), "No properties found", Toast.LENGTH_SHORT).show();
            return;
        }

        for (Property property : allProperties) {
            View itemView = LayoutInflater.from(getContext())
                    .inflate(R.layout.item_admin_property_toggle, container, false);

            TextView title = itemView.findViewById(R.id.txtPropertyTitle);
            Button toggle = itemView.findViewById(R.id.btnToggleFeatured);

            title.setText(property.getTitle());

            boolean isFeatured = false;
            for (Property featured : featuredList) {
                if (featured.getId() == property.getId()) {
                    isFeatured = true;
                    break;
                }
            }

            toggle.setText(isFeatured ? "Unmark as Featured" : "Mark as Featured");

            toggle.setOnClickListener(v -> {
                db.toggleFeatured(property.getId());
                loadProperties(); // Refresh list after change
            });

            container.addView(itemView);
        }
    }

}
