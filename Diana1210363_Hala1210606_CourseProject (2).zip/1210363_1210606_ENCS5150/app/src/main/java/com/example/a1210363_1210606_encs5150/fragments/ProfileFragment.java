package com.example.a1210363_1210606_encs5150.fragments;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import android.media.MediaScannerConnection;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.regex.Pattern;

public class ProfileFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    EditText editFirstName, editLastName, editPhone, editPassword;
    ImageView imageProfile;
    Button btnSaveProfile;

    SharedPreferences prefs;
    private static final String PREF_NAME = "LoginPrefs";
    private static final String KEY_EMAIL = "email";
    private String userEmail;

    DatabaseHelper db;

    private byte[] imageByteArray = null;  // this will store image as byte array

    public ProfileFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize views
        editFirstName = view.findViewById(R.id.editFirstName);
        editLastName = view.findViewById(R.id.editLastName);
        editPhone = view.findViewById(R.id.editPhone);
        editPassword = view.findViewById(R.id.editPassword);
        ImageView imgTogglePassword = view.findViewById(R.id.imgTogglePassword);
        imageProfile = view.findViewById(R.id.imageProfile);
        btnSaveProfile = view.findViewById(R.id.btnSaveProfile);

        final boolean[] isPasswordVisible = {false};

        imgTogglePassword.setOnClickListener(v -> {
            if (isPasswordVisible[0]) {
                editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                imgTogglePassword.setImageResource(R.drawable.ic_eye_closed);
            } else {
                editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                imgTogglePassword.setImageResource(R.drawable.ic_eye_open);
            }
            editPassword.setSelection(editPassword.getText().length());
            isPasswordVisible[0] = !isPasswordVisible[0];
        });

        prefs = getActivity().getSharedPreferences(PREF_NAME, getActivity().MODE_PRIVATE);
        userEmail = prefs.getString(KEY_EMAIL, "");

        db = new DatabaseHelper(getContext());

        loadUserInfo();

        btnSaveProfile.setOnClickListener(v -> updateUserInfo());

        imageProfile.setOnClickListener(v -> openGallery());

        return view;
    }

    private void loadUserInfo() {
        Cursor cursor = db.getReadableDatabase().rawQuery("SELECT * FROM users WHERE email = ?", new String[]{userEmail});
        if (cursor.moveToFirst()) {
            editFirstName.setText(cursor.getString(cursor.getColumnIndexOrThrow("firstName")));
            editLastName.setText(cursor.getString(cursor.getColumnIndexOrThrow("lastName")));
            editPhone.setText(cursor.getString(cursor.getColumnIndexOrThrow("phone")));
            editPassword.setText(cursor.getString(cursor.getColumnIndexOrThrow("password")));

            // Load image if exists
            int imageColumnIndex = cursor.getColumnIndex("profileImage");
            if (imageColumnIndex != -1 && !cursor.isNull(imageColumnIndex)) {
                byte[] imageBytes = cursor.getBlob(imageColumnIndex);
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                imageProfile.setImageBitmap(bitmap);
                imageByteArray = imageBytes;  // store loaded image in memory for update later
            }
        }
        cursor.close();
    }

    private void updateUserInfo() {
        String firstName = editFirstName.getText().toString().trim();
        String lastName = editLastName.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isValidPassword(password)) {
            Toast.makeText(getContext(), "Password must contain at least 6 characters, 1 uppercase, 1 lowercase, 1 number, 1 special character", Toast.LENGTH_LONG).show();
            return;
        }

        if (imageByteArray == null) {
            // optional: show warning if image not selected
            Toast.makeText(getContext(), "Please select profile picture!", Toast.LENGTH_SHORT).show();
            return;
        }

        db.getWritableDatabase().execSQL(
                "UPDATE users SET firstName = ?, lastName = ?, phone = ?, password = ?, profileImage = ? WHERE email = ?",
                new Object[]{firstName, lastName, phone, password, imageByteArray, userEmail}
        );

        Toast.makeText(getContext(), "Profile updated successfully!", Toast.LENGTH_SHORT).show();
    }

    private boolean isValidPassword(String password) {
        Pattern PASSWORD_PATTERN = Pattern.compile(
                "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{6,}$"
        );
        return PASSWORD_PATTERN.matcher(password).matches();
    }


    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(requireActivity().getContentResolver(), selectedImageUri);
                imageProfile.setImageBitmap(bitmap);
                imageByteArray = convertBitmapToByteArray(bitmap);  // convert image to byte[]
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private byte[] convertBitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }
    private void scanFile(String filePath) {
        MediaScannerConnection.scanFile(
                getContext(),
                new String[]{filePath},
                null,
                (path, uri) -> {
                    // Optional: you can print here when scan is finished
                    System.out.println("Scanned: " + path);
                }
        );
    }

}