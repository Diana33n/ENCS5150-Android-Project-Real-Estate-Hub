package com.example.a1210363_1210606_encs5150.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;

import java.util.ArrayList;
import java.util.List;

public class SpecialOffersFragment extends Fragment {

    private ListView listView;
    private DatabaseHelper db;
    private List<Property> properties;

    public SpecialOffersFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_special_offers, container, false);

        listView = view.findViewById(R.id.listViewProperties);
        db = new DatabaseHelper(requireContext());

        loadProperties();

        listView.setOnItemClickListener((parent, v, position, id) -> {
            Property selected = properties.get(position);
            db.toggleFeatured(selected.getId());
            Toast.makeText(getContext(), "Toggled Featured: " + selected.getTitle(), Toast.LENGTH_SHORT).show();
            loadProperties(); // Refresh list after toggle
        });

        return view;
    }

    private void loadProperties() {
        properties = db.getAllProperties(); // Full objects
        List<String> titles = new ArrayList<>();

        for (Property property : properties) {
            titles.add(property.getTitle());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, titles);
        listView.setAdapter(adapter);
    }
}
