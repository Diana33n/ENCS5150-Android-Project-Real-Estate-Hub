package com.example.a1210363_1210606_encs5150.activities;

import android.text.InputType;
import android.widget.ImageView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;

public class LoginActivity extends AppCompatActivity {

    EditText editEmail, editPassword;
    CheckBox checkboxRemember;
    Button btnLogin, btnToRegister;
    DatabaseHelper db;

    SharedPreferences prefs;
    private static final String PREF_NAME = "LoginPrefs";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_REMEMBER = "remember";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);

        // Added by Hala: Initialize the eye icon logic
        ImageView imgTogglePassword = findViewById(R.id.imgTogglePassword);
        final boolean[] isPasswordVisible = {false};
        imgTogglePassword.setOnClickListener(v -> {
            if (isPasswordVisible[0]) {
                editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                imgTogglePassword.setImageResource(R.drawable.ic_eye_closed);
            } else {
                editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                imgTogglePassword.setImageResource(R.drawable.ic_eye_open);
            }
            editPassword.setSelection(editPassword.getText().length());
            isPasswordVisible[0] = !isPasswordVisible[0];
        });

        checkboxRemember = findViewById(R.id.checkboxRemember);
        btnLogin = findViewById(R.id.btnLogin);
        btnToRegister = findViewById(R.id.btnToRegister);
        db = new DatabaseHelper(this);
        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Restore saved email if remembered
        if (prefs.getBoolean(KEY_REMEMBER, false)) {
            editEmail.setText(prefs.getString(KEY_EMAIL, ""));
            checkboxRemember.setChecked(true);
        }

        btnLogin.setOnClickListener(v -> {
            String email = editEmail.getText().toString().trim();
            String password = editPassword.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save email if "Remember Me" is checked
            if (checkboxRemember.isChecked()) {
                prefs.edit()
                        .putString(KEY_EMAIL, email)
                        .putBoolean(KEY_REMEMBER, true)
                        .apply();
            } else {
                prefs.edit().clear().apply();
            }

            // Replaced by Hala: old static admin check replaced by dynamic DB check
            if (db.checkUser(email, password)) {
                String role = db.getUserRole(email); // Added by Hala

                if ("admin".equals(role)) {
                    Toast.makeText(this, "Admin login successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LoginActivity.this, AdminHomeActivity.class)); // Added by Hala
                } else {
                    Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                }
                finish();
            } else {
                Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
            }
        });

        btnToRegister.setOnClickListener(v -> {
            startActivity(new Intent(this, RegisterActivity.class));
        });
    }
}
