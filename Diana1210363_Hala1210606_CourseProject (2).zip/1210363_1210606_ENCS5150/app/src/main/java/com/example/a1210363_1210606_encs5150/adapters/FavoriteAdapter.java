// FavoriteAdapter.java
package com.example.a1210363_1210606_encs5150.adapters;

import android.os.Bundle;
import android.view.*;
import android.widget.*;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.fragments.ReservationDetailsFragment;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;

import java.util.List;

public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.ViewHolder> {

    private FragmentActivity activity;
    private List<Property> favorites;
    private String userEmail;
    private DatabaseHelper dbHelper;

    public FavoriteAdapter(FragmentActivity activity, List<Property> favorites, String userEmail, DatabaseHelper dbHelper) {
        this.activity = activity;
        this.favorites = favorites;
        this.userEmail = userEmail;
        this.dbHelper = dbHelper;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.item_favorite, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Property property = favorites.get(position);

        holder.textTitle.setText(property.getTitle());
        holder.textLocation.setText(property.getLocation());
        holder.textPrice.setText("$" + property.getPrice());
        holder.textType.setText(property.getType());
        Glide.with(holder.itemView.getContext()).load(property.getImage()).into(holder.imageProperty);

        holder.btnReserve.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putSerializable("property", property);

            ReservationDetailsFragment fragment = new ReservationDetailsFragment();
            fragment.setArguments(bundle);

            activity.getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.content_frame, fragment)
                    .addToBackStack(null)
                    .commit();
        });

        holder.btnRemove.setOnClickListener(v -> {
            dbHelper.removeFavorite(userEmail, property.getId());
            favorites.remove(position);
            notifyItemRemoved(position);
            Toast.makeText(activity, "Removed from favorites", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return favorites.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageProperty;
        TextView textTitle, textLocation, textPrice, textType;
        Button btnReserve, btnRemove;

        public ViewHolder(View itemView) {
            super(itemView);
            imageProperty = itemView.findViewById(R.id.imageProperty);
            textTitle = itemView.findViewById(R.id.textTitle);
            textLocation = itemView.findViewById(R.id.textLocation);
            textPrice = itemView.findViewById(R.id.textPrice);
            textType = itemView.findViewById(R.id.textType);
            btnReserve = itemView.findViewById(R.id.btnReserve);
            btnRemove = itemView.findViewById(R.id.btnRemove);
        }
    }
}
