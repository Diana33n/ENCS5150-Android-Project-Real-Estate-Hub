package com.example.a1210363_1210606_encs5150.fragments;

import android.os.Bundle;
import android.text.InputType; // ✅ REQUIRED!
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.fragment.app.Fragment;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.User;

import java.util.ArrayList;
import java.util.List;

public class AddAdminFragment extends Fragment {
    String[] countryCodes = {"+970", "+962", "+20"};


    private EditText editFirstName, editLastName, editEmail, editPassword, editConfirmPassword, editPhone;
    private Spinner spinnerGender, spinnerCountry, spinnerCity;
    private Button btnAddAdmin;
    private DatabaseHelper db;

    private ImageView togglePasswordVisibility, toggleConfirmPasswordVisibility;
    private boolean isPasswordVisible = false;
    private boolean isConfirmPasswordVisible = false;

    public AddAdminFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_admin, container, false);

        try {
            db = new DatabaseHelper(getContext());

            // Initialize all views
            editFirstName = view.findViewById(R.id.editFirstName);
            editLastName = view.findViewById(R.id.editLastName);
            editEmail = view.findViewById(R.id.editEmail);
            editPassword = view.findViewById(R.id.editPassword);
            editConfirmPassword = view.findViewById(R.id.editConfirmPassword);
            editPhone = view.findViewById(R.id.editPhone);
            spinnerGender = view.findViewById(R.id.spinnerGender);
            spinnerCountry = view.findViewById(R.id.spinnerCountry);
            spinnerCity = view.findViewById(R.id.spinnerCity);
            btnAddAdmin = view.findViewById(R.id.btnAddAdmin);

            togglePasswordVisibility = view.findViewById(R.id.togglePassword);
            toggleConfirmPasswordVisibility = view.findViewById(R.id.toggleConfirmPassword);

            // Toggle password visibility
            togglePasswordVisibility.setOnClickListener(v -> {
                if (isPasswordVisible) {
                    editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    togglePasswordVisibility.setImageResource(R.drawable.ic_eye_closed);
                } else {
                    editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    togglePasswordVisibility.setImageResource(R.drawable.ic_eye_open);
                }
                isPasswordVisible = !isPasswordVisible;
                editPassword.setSelection(editPassword.getText().length());
            });

            // Toggle confirm password visibility
            toggleConfirmPasswordVisibility.setOnClickListener(v -> {
                if (isConfirmPasswordVisible) {
                    editConfirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    toggleConfirmPasswordVisibility.setImageResource(R.drawable.ic_eye_closed);
                } else {
                    editConfirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    toggleConfirmPasswordVisibility.setImageResource(R.drawable.ic_eye_open);
                }
                isConfirmPasswordVisible = !isConfirmPasswordVisible;
                editConfirmPassword.setSelection(editConfirmPassword.getText().length());
            });

            setupSpinners();

            btnAddAdmin.setOnClickListener(v -> {
                try {
                    addAdmin();
                } catch (Exception e) {
                    Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e("AddAdmin", "Error adding admin", e);
                }
            });
        } catch (Exception e) {
            Toast.makeText(getContext(), "Initialization error", Toast.LENGTH_SHORT).show();
            Log.e("AddAdmin", "Initialization error", e);
        }

        return view;
    }


    private void setupSpinners() {
        List<String> genders = new ArrayList<>();
        genders.add("Gender");
        genders.add("Male");
        genders.add("Female");

        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, genders);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGender.setAdapter(genderAdapter);

        List<String> countries = new ArrayList<>();
        countries.add("Country");
        countries.add("Palestine");
        countries.add("Jordan");
        countries.add("Egypt");

        ArrayAdapter<String> countryAdapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, countries);
        countryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCountry.setAdapter(countryAdapter);

        List<String> cities = new ArrayList<>();
        cities.add("City");

        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, cities);
        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCity.setAdapter(cityAdapter);

        spinnerCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    updateCitiesSpinner(spinnerCountry.getSelectedItem().toString());
                    editPhone.setText(countryCodes[position - 1]);
                    editPhone.setSelection(editPhone.getText().length()); // ✅ move cursor after +code
                } else {
                    editPhone.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });


    }

    private void updateCitiesSpinner(String country) {
        List<String> cities = new ArrayList<>();
        cities.add("City");

        switch (country) {
            case "Palestine":
                cities.add("Ramallah");
                cities.add("Nablus");
                cities.add("Hebron");
                break;
            case "Jordan":
                cities.add("Amman");
                cities.add("Zarqa");
                cities.add("Irbid");
                break;
            case "Egypt":
                cities.add("Cairo");
                cities.add("Alexandria");
                cities.add("Giza");
                break;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, cities);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCity.setAdapter(adapter);
    }
    private boolean validateInputs() {
        String email = editEmail.getText().toString().trim();
        String fName = editFirstName.getText().toString().trim();
        String lName = editLastName.getText().toString().trim();
        String pass = editPassword.getText().toString();
        String conf = editConfirmPassword.getText().toString();
        String phone = editPhone.getText().toString().trim();

        if (fName.isEmpty() || lName.isEmpty() || email.isEmpty()
                || pass.isEmpty() || conf.isEmpty() || phone.isEmpty()) {
            Toast.makeText(getContext(), "All fields must be filled", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (spinnerGender.getSelectedItemPosition() == 0 ||
                spinnerCountry.getSelectedItemPosition() == 0 ||
                spinnerCity.getSelectedItemPosition() == 0) {
            Toast.makeText(getContext(), "Please select gender, country, and city", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")) {
            editEmail.setError("Invalid email format");
            return false;
        }

        if (fName.length() < 3 || lName.length() < 3 || fName.matches(".*\\d.*") || lName.matches(".*\\d.*")) {
            Toast.makeText(getContext(), "Name must be at least 3 characters and contain no numbers", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!pass.matches("^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{6,}$")) {
            editPassword.setError("Password must be 6+ chars, include letter, number & symbol");
            return false;
        }

        if (!pass.equals(conf)) {
            editConfirmPassword.setError("Passwords do not match");
            return false;
        }

        return true;
    }


    private void addAdmin() {
        try {
            if (!validateInputs()) return;
            String firstName = editFirstName.getText().toString().trim();
            String lastName = editLastName.getText().toString().trim();
            String email = editEmail.getText().toString().trim();
            String password = editPassword.getText().toString().trim();
            String confirmPassword = editConfirmPassword.getText().toString().trim();
            String phone = editPhone.getText().toString().trim();

            if (spinnerGender.getSelectedItemPosition() <= 0 ||
                    spinnerCountry.getSelectedItemPosition() <= 0 ||
                    spinnerCity.getSelectedItemPosition() <= 0) {
                Toast.makeText(getContext(), "Please select all dropdown values", Toast.LENGTH_SHORT).show();
                return;
            }

            String gender = spinnerGender.getSelectedItem().toString();
            String country = spinnerCountry.getSelectedItem().toString();
            String city = spinnerCity.getSelectedItem().toString();

            if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() ||
                    password.isEmpty() || confirmPassword.isEmpty() || phone.isEmpty()) {
                Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(getContext(), "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            User admin = new User(firstName, lastName, email, password,
                    gender, country, city, phone, "admin");

            long result = db.insertAdmin(admin);
            if (result != -1) {
                Toast.makeText(getContext(), "Admin added successfully", Toast.LENGTH_SHORT).show();
                clearFields();
            } else {
                Toast.makeText(getContext(), "Error: email already exists or database error", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            Toast.makeText(getContext(), "Error adding admin: " + e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e("AddAdmin", "Error in addAdmin", e);
        }
    }

    private void clearFields() {
        editFirstName.setText("");
        editLastName.setText("");
        editEmail.setText("");
        editPassword.setText("");
        editConfirmPassword.setText("");
        editPhone.setText("");
        spinnerGender.setSelection(0);
        spinnerCountry.setSelection(0);
        spinnerCity.setSelection(0);
    }
}
