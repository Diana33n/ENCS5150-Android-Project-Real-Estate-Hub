package com.example.a1210363_1210606_encs5150.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.adapters.ReservationAdapter;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.ReservationDisplay;

import java.util.List;

public class YourReservationsFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView textEmpty;
    private ReservationAdapter adapter;
    private DatabaseHelper db;

    public YourReservationsFragment() {}

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_your_reservations, container, false);

        recyclerView = view.findViewById(R.id.recyclerReservations);
        textEmpty    = view.findViewById(R.id.textEmpty);
        db           = new DatabaseHelper(requireContext());

        SharedPreferences prefs = requireContext()
                .getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);

        String email = prefs.getString("email", null);
        if (email == null) {
            Toast.makeText(requireContext(),
                    "Please log in first",
                    Toast.LENGTH_SHORT).show();

            textEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
            return view;          // أعد الـ View بدل return;
        }

        List<ReservationDisplay> reserved = db.getReservationsWithDate(email);

        if (reserved.isEmpty()) {
            textEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            textEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            adapter = new ReservationAdapter(requireContext(), reserved);
            recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
            recyclerView.setAdapter(adapter);
        }

        return view;
    }

}
