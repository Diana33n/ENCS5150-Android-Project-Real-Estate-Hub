package com.example.a1210363_1210606_encs5150.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.a1210363_1210606_encs5150.R;
import com.example.a1210363_1210606_encs5150.adapters.PropertyAdapter;
import com.example.a1210363_1210606_encs5150.helpers.DatabaseHelper;
import com.example.a1210363_1210606_encs5150.models.Property;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class PropertiesFragment extends Fragment {

    private RecyclerView recyclerViewProperties;
    private PropertyAdapter propertyAdapter;
    private List<Property> propertyList;
    private SearchView searchView;
    private Spinner typeSpinner;
    private DatabaseHelper dbHelper;

    public PropertiesFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_properties, container, false);

        recyclerViewProperties = view.findViewById(R.id.recyclerViewProperties);
        searchView = view.findViewById(R.id.searchView);
        typeSpinner = view.findViewById(R.id.typeFilterSpinner);
        propertyList = new ArrayList<>();
        dbHelper = new DatabaseHelper(getContext());

        recyclerViewProperties.setLayoutManager(new LinearLayoutManager(getContext()));
        propertyAdapter = new PropertyAdapter(requireActivity(), propertyList);
        recyclerViewProperties.setAdapter(propertyAdapter);

        loadPropertiesFromAPI();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                propertyAdapter.filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                propertyAdapter.filter(newText);
                return false;
            }
        });

        return view;
    }

    private void loadPropertiesFromAPI() {
        String url = "https://api.jsonbin.io/v3/b/6846db708561e97a50216a00";
        RequestQueue queue = Volley.newRequestQueue(getContext());

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONObject record = response.getJSONObject("record");
                        JSONArray propertiesArray = record.getJSONArray("properties");
                        propertyList.clear();

                        for (int i = 0; i < propertiesArray.length(); i++) {
                            JSONObject obj = propertiesArray.getJSONObject(i);
                            Property property = new Property();
                            property.setId(obj.getInt("id"));
                            property.setTitle(obj.getString("title"));
                            property.setDescription(obj.getString("description"));
                            property.setPrice(obj.getDouble("price"));
                            property.setLocation(obj.getString("location"));
                            property.setImage(obj.getString("image_url"));
                            property.setType(obj.getString("type"));

                            propertyList.add(property);
                            dbHelper.insertProperty(property); // ✅ يخزن في قاعدة البيانات
                        }

                        propertyAdapter = new PropertyAdapter(requireActivity(), propertyList);
                        recyclerViewProperties.setAdapter(propertyAdapter);

                        String[] types = {"All", "Apartment", "Villa", "Land"};
                        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, types);
                        typeSpinner.setAdapter(spinnerAdapter);

                        typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                String selectedType = types[position];
                                propertyAdapter.filterByType(selectedType);
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {}
                        });

                    } catch (Exception e) {
                        Toast.makeText(getContext(), "Error parsing data", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                },
                error -> {
                    Toast.makeText(getContext(), "Connection error", Toast.LENGTH_SHORT).show();
                    error.printStackTrace();
                });

        queue.add(request);
    }
}
